# Playbooks

## Description
Playbooks collection

## List of playbooks

* [users](./README.md#users) - user access deployment playbook
* [databases](./README.md#databases) - database access deployment playbook
* [test](./test/README.md) - testing contour playbooks for `.test.env` domain
* [prod](./prod/README.md) - production contour playbooks for `.prod.env` domain
* [adhoc](./adhoc/README.md) - ad-hoc playbook for different purposes

## Playbook description

### users

#### Description

Common user playbook for deploy user and send creds via slack

#### Usage

For user object determination and details how it works please [visit](../roles/users/README.md)

In the code-box below you can find common example of playbook execution

```shell
./venv/bin/ansible-playbook ./playbooks/users.yml \
  -e _debug='True' \
  -e ansible__working_directory="/Users/vvoitenko/gits/exness/infra/iac" \
  -e users__user_name='vadim_voitenko' \
  -e users__databases_filter="['postgresql_recon_db_prd_test:bitcoin']" \
  -e users__send_to_slack=True
```

Where:

* _debug - Is not required. Debug print all helpful data
* ansible__working_directory - repository root path
* users__user_name - name of file which contain user object definition.
  For [instance](../vars/users/common/vadim_voitenko.yml)
* users__databases_filter - list for databases which must be deployed. If this list will not be determined all user
  access from object file will be deployed. This list consist from the string object with format
  "{{cluster_name}}:{{database_name}}"
* users__send_to_slack - send generated credentials to slack


#### Users on shared clusters

To create users on shared clusters, you should create the same user on every shard-cluster. The passwords for these users will be the same and will be stored in the postgresql-shards directory in the vault, instead of in the postgresql directory.


### databases

For database object determination and details how it works please [visit](../roles/databases/README.md)

In the code-box below you can find common example of playbook execution

```shell
./venv/bin/ansible-playbook ./playbooks/databases.yml \
  -e _debug='True' \
  -e ansible__working_directory="/Users/vvoitenko/gits/exness/infra/iac" \
  -e databases__cluster_name='postgresql_iac_test' \
  -e databases__database_name='testdb'
```

Where:

* _debug - Is not required. Debug print all helpful data
* ansible__working_directory - repository root path
* databases__cluster_name - name of cluster which located in vars
  directory ([example](../vars/databases/cluster/postgresql_abs_wallet_prod.yml))
* databases__database_name - name of database from `databases__cluster_name` object file which must be deployed
