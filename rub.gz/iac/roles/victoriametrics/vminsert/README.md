TODO:
 * httpAuth.username
 * httpAuth.password
 * tls
 * tlsCertFile
 * tlsKeyFile