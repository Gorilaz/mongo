# Infrastructure As Code (IAC) for DBMS 

## Responsible
- Code owner: [Dmitry Alexandrov](https://exness.slack.com/team/U5LGL36QP)
- Product owner: [Nokolay Belov](https://exness.slack.com/team/U0JRLNU6R)
- Architecture: [Vadim Voitenko](https://exness.slack.com/team/U03KFEY3EUQ)
- Team: DBATeam (slack: @dba-team)
---

## Description 
The Infrastructure as code approach is using for manage, deploy and deliver appropriate instances during their lifecycle.
Using that approach allows us to define inventory and store it in reliable place. Playbooks and roles combined with 
inventories allows us to manage each instance independently and find any changes. Written roles have to guarantee 
idempotency in order to except any problems during deployment attempts and life-cycle usage.

---
## Requirements
* Unix-like OS (Linux/OSX)
* Python3.12
* Ansible
* Virtualenv or Docker
* VPN access in appropriate zones of your responsibility
* SSH access to machines
* Root user access in some tasks
---

## How to run

Note: Currently all roles collection and custom modules tested at Python3.12, please keep it in mind when you will decide
to use another python version

We have two options for IAC project installation:

* [Local virtual environment installation](./README.md#local-virtual-environment-installation) - is recommended 
  especially when you are designing and debugging your own modules, or you are struggling of docker system
* [Docker installation](./README.md#docker-installation) - is recommended when you want to build project docker 
  without deep understanding of configuration procedure


### Installation:

#### Local virtual environment installation
* Install python3.12, python3.12-venv, python3.12-pip
```shell
brew install python@3.12
```
* Open root git project directory
* Initialize virtual environment
* Activate virtual environment
* Install project requirements
```shell
python3.12 -m venv venv && source ./venv/bin/activate && pip install -r requirements.txt
```

### Configuration
* Make a copy of ansible.cfg.template file with name ansible.cfg
* Find setting called `remote_user` and write instead placeholder yur LDAP login
* Configure ansible vault. Get password via [link](https://exness.1password.com/vaults/wf7htqougbgsnfnjtjsuhpjgy4/allitems/m2wxdx5qrrokn6gwpx5lc3wjoa)
and write content into file .vault_password_file
* Since we have not found the best solution which would provide ansible root directory of the project we have
made it via hardcode. You need to find variable `ansible__working_directory` and set value to your git project 
location. It will be deprecated as soon as we find an appropriate solution
* For OSX users setting up `export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES` is required otherwise fork exception may be 
occurred


#### Docker installation

* Install docker and docker-compose

* Set up environment variables
```shell
export ARCH=aarch64 #If you are using ARM architecture
export ARCH=x86_64 #If you are using x86 architecture
```
Build docker-compose service 
```shell
docker-compose build ansible_local
```
Run docker-compose service
```shell
docker-compose run ansible_local
```


## Testing

In order to make a check run the command 
```shell
ansible dba-iac-test-01.test.env -m ping
```

---

## Agreement and development recommendation

Read development recommendations and agreement [here](https://confluence.exness.io/pages/viewpage.action?pageId=169886593)

---

## Roles
[Roles list](./roles/README.md)

Roles locating in `./roles` directory. Here you can find roles and collection. 

The main idea in roles development: each role should do only responsible features connected with its description.
For instance when we are making roles for postgresql deployment we shouldn't implement it monolithic since later we will
not be able to reuse it. We should split one purpose (postgresql deployment) on short subtasks like 
`postgresql/install`, `postgresql/monitoring` etc. This approach is powerful for contribution and provide code re-using
in another roles and playbooks.

---

## Playbooks

For details about playbooks applying please [visit](./playbooks/README.md)

---

## Inventory

For details about inventory structure please [visit](./inventories/README.md)

---

## TODO:



