# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.1] - 2023-09-12

New features:
* Added new restart behaviour for `postgresql` role
  * `postgresql__primary_restart_allowed` (default False) - Using this var it's possible to exclude the primary 
    (master) from the restart task. Plays with can_restart and must_restart as usual. By default primary is not 
    restarting excluding `postgresql__init`
  * `postgresql__allowed_restart_nodes` (default []) - list of the nodes allowed to restart. Plays with
  `postgresql__[can|must]_restart` and `postgresql__pgbouncer_[can|must]_restart`. For instance if 
  `postgresql__primary_restart_allowed=False` then in redeployment with `postgresql__pgbouncer_[can|must]_restart` and
  `postgresql__[can|must]_restart` only PostgreSQL replicas and PGBouncer on replicas instances will be restarted  
  * `postgresql__pgbouncer_allowed_restart_nodes` - the same as in previous but for pgbouncer
  * `postgresql__init flag` Allows restart of the whole cluster including primary. Useful in initial setup.
  It sets as *True*
    * `postgresql__primary_restart_allowed`
    * `postgresql__must_restart`
    * `postgresql__pgbouncer_must_restart`
    * `postgresql__barman_skip_check_errors`

### Usecases:

#### Init

Now you do not need to set up manually  `-e postgresql__primary_restart_allowed=True -e postgresql__must_restart=True -e 
postgresql__pgbouncer_must_restart=True -e postgresql__barman_skip_check_errors=True `

`ansible-playbook playbooks/test/postgresql/postgresql_iac_test.yml -e postgresql__init=True`

#### Adding a new node to existing cluster. 
In this case can|must behaviour must be determined

`ansible-playbook ./playbooks/prod/postgresql/postgresql_abs_trx_s03_prod.yml -e "postgresql__pgbouncer_must_restart=True" -e "postgresql__must_restart=True" -e postgresql__allowed_restart_nodes='["ld-abs-trx-s03-db-01.prod.trust.env", "ld-abs-trx-s03-db-02.prod.trust.env"]' -e postgresql__pgbouncer_allowed_restart_nodes='["ld-abs-trx-s03-db-01.prod.trust.env", "ld-abs-trx-s03-db-02.prod.trust.env"]'`


#### Restart PostgreSQL WITHOUT primary

`ansible-playbook playbooks/test/postgresql/postgresql_iac_test.yml -e postgresql__must_restart=True`


#### Restart PostgreSQL WITH primary

`ansible-playbook playbooks/test/postgresql/postgresql_iac_test.yml -e postgresql__must_restart=True -e postgresql__primary_restart_allowed=True`

#### Restart PGBouncer WITHOUT primary

`ansible-playbook playbooks/test/postgresql/postgresql_iac_test.yml -e postgresql__pgbouncer_must_restart=True`

#### Restart PGBouncer WITH primary
`ansible-playbook playbooks/test/postgresql/postgresql_iac_test.yml -e postgresql__pgbouncer_must_restart=True -e postgresql__primary_restart_allowed=True`


Fixes:
* Fixed percona repo deployment

MR:
* [ITDBA-1126](https://git.exness.io/dba/iac/-/merge_requests/484)



