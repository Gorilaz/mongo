#!/usr/bin/python

"""
Script for joining teleport connectors divided by independent files. This is required for sharing
connectors with ITS team

For running use:
./tools/teleport_join_connectors.py ./teleport_files

where ./teleport_files is directory to the teleport folder located in the IAC git repo root

For running with custom file mask use:
./tools/teleport_join_connectors.py ./teleport_files "*-connector.hcl"

where "*-connector.hcl" is file mask for joining connectors

For running with custom delimiter use:
./tools/teleport_join_connectors.py ./teleport_files "*-connector.hcl" ",\n"

where ",\n" is delimiter for joining connectors
"""

import glob
import sys


def main():
    args = sys.argv[1:]
    if len(args) == 0:
        raise Exception("Path to teleport metadata is required")
    path = args[0]
    file_mask = args[1] if len(args) > 1 else "*-connector.hcl"
    delimiter = args[2].replace('\\n', '\n') if len(args) > 2 else ",\n"

    file_names = glob.glob("{}/{}".format(path, file_mask))
    file_names.sort()

    connectors_data = []
    for file_name in file_names:
        with open(file_name, "r") as f:
            data = f.read().strip()
            connectors_data.append(data)

    res = '{}'.format(delimiter).join(connectors_data)
    print(res)


if __name__ == "__main__":
    main()
