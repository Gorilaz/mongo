import os
import sys
import time

import yaml


def read_yaml(inventory_path):
    file_name = os.path.basename(inventory_path).split(".")[0]

    with open(inventory_path, "r") as f:
        data = yaml.safe_load(f)

    return list(data["all"]["children"][file_name]["children"].keys())


groups = [
    # "postgresql_abs_trx_s03_prod_new",
    # "postgresql_abs_trx_s04_prod_new",

    # "postgresql_bat_prod_trust", # TODO: Failed
    # TASK [postgresql/repmgr : Update authorized_keys on all nodes] *****************
    # skipping: [bat-db-01.prod.trust.env] => (item=None)
    # fatal: [bat-db-01.prod.trust.env]: FAILED! =>
    #   censored: 'the output has been hidden due to the fact that ''no_log: true'' was specified for this result'

    "postgresql_db_prod_trust",
    "postgresql_abs_internal_transfers_prod_trust",
    "postgresql_abs_temporal_prod_trust",
    "postgresql_abs_db_prod_trust",

    "postgresql_abs_bo_api_prod_trust",
    "postgresql_abs_db_ld_prod_trust",
    "postgresql_abs_ops_pib_db_nl_prod_trust",
    "postgresql_abs_ops_pib_db_ld_prod_trust",
    "postgresql_abs_ops_billing_prod_trust",
    "postgresql_ld_abs_wallets_manager_prod_trust",

    # "postgresql_abs_ops_pda_nl_prod_trust", # EPEL err
    # "postgresql_abs_ops_pda_ld_prod_trust", # EPEL err

    "postgresql_partner_reward_credit_prod_trust",
    "postgresql_card_processing_prod_trust",
    "postgresql_tron_approver_prod_trust",
    "postgresql_awd_db_prod_trust",
    "postgresql_crypto_addresses_prod_trust",
    "postgresql_invoice_approver_prod_trust",
    "postgresql_teleport_prod_trust",
    "postgresql_psp_processing_prod_trust",
    "postgresql_abs_acc_operations_trading_ld_prod_trust",
    "postgresql_initial_approver_prod_trust",
    "postgresql_bitcoin_approver_prod_trust",
]

playbook_path = "playbooks/adhoc/postgresql_common.yml"


def play(inventory_group):
    print(f"****************** PLAYING FOR {inventory_group} ******************", flush=True)

    executable = f"ansible-playbook {playbook_path} -l {inventory_group} -t postgresql_config -e ansible__working_directory={work_dir} -e _debug=True"
    print(executable, flush=True)

    res = os.system(executable)

    if res != 0:
        raise Exception("non zero exit code")

    print("****************** WAITING 60 SECONDS ******************", flush=True)
    time.sleep(60)


if __name__ == "__main__":

    start_from = sys.argv[3]
    work_dir = sys.argv[2]
    inventory_path = sys.argv[1]
    inventory_groups = read_yaml(inventory_path)
    print("Starting from " + start_from, flush=True)
    skip = True
    for group in inventory_groups:
        if skip:
            if group == start_from:
                print("starting from ", group, flush=True)
                skip = False
            else:
                print("skip group ", group, flush=True)
                continue

        play(group)
