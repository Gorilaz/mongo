from ansible.module_utils.basic import AnsibleModule
import clickhouse_driver
from clickhouse_driver.errors import NetworkError, ServerException, Error
from enum import Enum


DOCUMENTATION = r'''
module: clickhouse_user_management
short_description: Manages users in ClickHouse with cluster, LDAP, and default role support.
version_added: "1.0.0"
description: >
    This module allows for the creation, modification, and deletion of ClickHouse users, 
    including support for operations on a cluster, creating LDAP users, and setting default roles.
options:
    ch_host:
        description: Hostname or IP of the ClickHouse server.
        required: true
        type: str
    ch_port:
        description: Port number of the ClickHouse server.
        required: false
        default: 9000
        type: int
    ch_user:
        description: Username for authentication with the ClickHouse server.
        required: false
        default: 'default'
        type: str
    ch_password:
        description: Password for authentication with the ClickHouse server.
        required: false
        default: ''
        type: str
    state:
        description: Desired state of the user ('absent' or 'present').
        required: false
        default: 'present'
        type: str
        choices: ['absent', 'present']
    username:
        description: Name of the user to manage.
        required: true
        type: str
    password:
        description: Password for the user (for create and modify actions, not required for LDAP users).
        required: false
        type: str
    roles:
        description: List of privileges to be granted (for create and modify actions).
        required: false
        default: []
        type: list
        elements: str
    settings_profile:
        description: User settings profile.
        required: false
        type: str
    cluster_name:
        description: Name of the cluster to perform the operation on (optional).
        required: false
        type: str
    ldap_server_name:
        description: The LDAP server name for creating LDAP users (optional).
        required: false
        type: str
    set_default_roles:
        description: Whether to set all roles as default for the user (optional).
        required: false
        default: true
        type: bool
    force:
        description: Whether to force the operation (optional).
        required: false
        default: false
        type: bool
author:
    - Dmitry Nikitin DBA <<dmitry.nikitin@exness.com>>
'''

EXAMPLES = r'''
- name: Create a user in ClickHouse
  clickhouse_user_management:
    ch_host: 'clickhouse-server.example.com'
    ch_user: 'admin'
    ch_password: 'password'
    state: 'present'
    username: 'test_user'
    password: 'test_password'
    roles:
        - 'role1'
        - 'role2'
    settings_profile: 'test_profile'
'''

RETURN = r'''
message:
    description: Detailed message about the result.
    returned: always
    type: str
'''


class Action(Enum):
    CREATE = 1
    MODIFY = 2
    DROP = 3
    NONE = 0


def execute_query(client, module, query):
    try:
        result = client.execute(query, with_column_types=True)
        return result
    except NetworkError as e:
        module.fail_json(msg=f"Network error occurred: {query}")
    except ServerException as e:
        module.fail_json(msg=f"Server returned an error: {query}")
    except Error as e:
        module.fail_json(msg=f"An error occurred: {query}")
    except Exception as e:
        module.fail_json(msg=f"Unexpected error: {query}")
    finally:
        client.disconnect()


def get_user_info(client, module, username):
    user_sql = '''
    SELECT u.name AS username,
    groupArray(if(length(rg.granted_role_name) > 0, rg.granted_role_name, NULL)) AS roles,
    spe.inherit_profile AS settings_profile
    FROM system.users AS u
    LEFT JOIN system.role_grants AS rg
    ON u.name = rg.user_name
    LEFT JOIN system.settings_profile_elements spe
    ON u.name = spe.user_name
    WHERE u.name = {}
    GROUP BY u.name, spe.inherit_profile;
    '''

    user_info_data, user_info_columns = execute_query(client, module, user_sql.format(username))
    user_info_column_names = [col[0] for col in user_info_columns]
    user_info_formatted_result = [dict(zip(user_info_column_names, row)) for row in user_info_data]
    if user_info_formatted_result:
        return user_info_formatted_result[0]
    return None


def validate_user_exists(client, module):
    username = f"'{module.params['username']}'"
    user_info = get_user_info(client, module, username)
    if user_info:
        return True
    return False


def validate_user_roles(client, module):
    username = f"'{module.params['username']}'"
    roles = module.params['roles']
    settings_profile = module.params['settings_profile']
    user_info = get_user_info(client, module, username)
    if user_info:
        if sorted(user_info['roles']) == sorted(list(set(roles))) and user_info['settings_profile'] == settings_profile:
            return True
    return False


def construct_sql(module, action):
    username = f"'{module.params['username']}'"
    cluster_suffix = f" ON CLUSTER {module.params['cluster_name']}" if module.params.get('cluster_name') else ""
    sql = ""
    if action == Action.CREATE or action == Action.MODIFY:
        if module.params.get('ldap_server_name'):
            auth_part = f"IDENTIFIED WITH ldap SERVER '{module.params['ldap_server_name']}'"
        else:
            auth_part = f"IDENTIFIED BY '{module.params['password']}'" if 'password' in module.params else ""
        roles_part = f"DEFAULT ROLE {', '.join(module.params.get('roles', []))}" if module.params.get('roles') else ""
        settings_profile_part = f"SETTINGS PROFILE '{module.params['settings_profile']}'" \
            if module.params.get('settings_profile') else ""
        if action == Action.CREATE:
            sql = (f"CREATE USER IF NOT EXISTS {username} {cluster_suffix} {auth_part} {roles_part} "
                   f"{settings_profile_part}")
        else:  # modify
            if module.params['force']:
                modify_parts = [auth_part, roles_part, settings_profile_part]
            else:
                modify_parts = [roles_part, settings_profile_part]
            modify_clause = " ".join(modify_parts)
            create_user_sql = (f"CREATE USER IF NOT EXISTS {username} {cluster_suffix} {auth_part} {roles_part} "
                               f"{settings_profile_part}")
            alter_user_sql = f"ALTER USER IF EXISTS {username} {cluster_suffix} {modify_clause}"
            revoke_roles_sql = (f"REVOKE {cluster_suffix} ALL EXCEPT {', '.join(module.params.get('roles', []))} "
                                f"FROM {username}")
            grant_roles_sql = f"GRANT {cluster_suffix} {', '.join(module.params.get('roles', []))} TO {username}"
            if not module.params.get('roles'):
                revoke_roles_sql = f"REVOKE {cluster_suffix} ALL FROM {username}"
                sql = [create_user_sql, revoke_roles_sql, alter_user_sql]
            else:
                sql = [create_user_sql, revoke_roles_sql, grant_roles_sql, alter_user_sql]
    elif action == Action.DROP:
        sql = f"DROP USER IF EXISTS {username} {cluster_suffix}"
    else:
        module.fail_json(msg="Invalid action specified.")
    return sql


def construct_default_role_sql(module):
    username = f"'{module.params['username']}'"
    cluster_suffix = f" ON CLUSTER {module.params['cluster_name']}" if module.params.get('cluster_name') else ""
    settings_profile_suffix = f" SETTINGS PROFILE '{module.params['settings_profile']}'" \
        if module.params.get('settings_profile') else ""
    sql = f"ALTER USER IF EXISTS {username} {cluster_suffix} DEFAULT ROLE ALL {settings_profile_suffix}"
    return sql


def run_module():
    module_args = {
        'ch_host': {'type': 'str', 'required': True},
        'ch_port': {'type': 'int', 'default': 9000},
        'ch_user': {'type': 'str', 'default': 'default'},
        'ch_password': {'type': 'str', 'no_log': True, 'default': ''},
        'state': {'type': 'str', 'required': False, 'default': 'present', 'choices': ['present', 'absent']},
        'username': {'type': 'str', 'required': True},
        'password': {'type': 'str', 'no_log': True, 'required': False},
        'roles': {'type': 'list', 'elements': 'str', 'default': []},
        'settings_profile': {'type': 'str'},
        'cluster_name': {'type': 'str'},
        'ldap_server_name': {'type': 'str'},
        'set_default_roles': {'type': 'bool', 'default': True},
        'force': {'type': 'bool', 'default': False},
    }

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    ch_host = module.params['ch_host']
    ch_port = module.params['ch_port']
    ch_user = module.params['ch_user']
    ch_password = module.params['ch_password']
    state = module.params['state']
    force = module.params['force']
    action = Action.NONE

    client = clickhouse_driver.Client(host=ch_host, port=ch_port, user=ch_user, password=ch_password)

    user_exists = validate_user_exists(client, module)

    if state == 'present' and user_exists:
        user_roles_valid = validate_user_roles(client, module)
        if user_roles_valid and not force:
            module.exit_json(changed=False,
                             message="User already exists with the specified roles and settings profile.")
        else:
            action = Action.MODIFY
    elif state == 'present' and not user_exists:
        action = Action.CREATE
    elif state == 'absent' and user_exists:
        action = Action.DROP
    else:
        module.exit_json(changed=False, message="User already in the desired state.")
    sql = construct_sql(module, action)
    if action == Action.MODIFY:
        for statement in sql:
            execute_query(client, module, statement)
    else:
        execute_query(client, module, sql)
    message = f"User {action.name} action completed successfully."

    if action != Action.DROP and module.params.get('set_default_roles', False):
        default_role_sql = construct_default_role_sql(module)
        execute_query(client, module, default_role_sql)
        message += " Default roles set."
    module.exit_json(changed=True, message=message)


def main():
    run_module()


if __name__ == '__main__':
    main()
