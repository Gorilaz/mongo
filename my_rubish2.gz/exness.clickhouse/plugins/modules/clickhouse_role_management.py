from ansible.module_utils.basic import AnsibleModule
import clickhouse_driver
from clickhouse_driver.errors import NetworkError, ServerException, Error
from enum import Enum

DOCUMENTATION = r'''
module: clickhouse_role_management
short_description: Manages roles in ClickHouse with privileges and settings support.
version_added: "1.0.0"
description: >
    This module allows for the creation, modification, and deletion of ClickHouse roles,
    including the assignment of privileges and additional settings or restrictions for roles.
options:
    ch_host:
        description: Hostname or IP of the ClickHouse server.
        required: true
        type: str
    ch_port:
        description: Port number of the ClickHouse server.
        required: false
        default: 9000
        type: int
    ch_user:
        description: Username for authentication with the ClickHouse server.
        required: false
        default: 'default'
        type: str
    ch_password:
        description: Password for authentication with the ClickHouse server.
        required: false
        type: str
    cluster_name:
        description: Name of the cluster to manage.
        required: false
        type: str
    state:
        description: Desired state of the role ('absent' or 'present').
        required: true
        type: str
        choices: ['absent', 'present']
    role:
        description: Name of the role to manage.
        required: true
        type: str
    privileges:
        description: List of privileges to be granted to the role (for 'present' state).
        required: false
        default: []
        type: list
        elements: dict
    settings_profile:
        description: Role settings profile.
        required: false
        type: str
    force:
        description: Whether to force the operation, applicable for 'present' state (optional).
        required: false
        default: False
        type: bool
author:
    - Dmitry Nikitin DBA <<dmitry.nikitin@exness.com>>
'''

EXAMPLES = r'''
- name: Ensure a role in ClickHouse is present with specific privileges and settings
  clickhouse_role_management:
    ch_host: 'clickhouse-server.example.com'
    ch_user: 'admin'
    ch_password: 'password'
    cluster_name: 'test_cluster'
    state: 'present'
    role: 'test_role'
    privileges:
      - { db: "test_db", table: "*", grants: ["SELECT"] }
'''

RETURN = r'''
message:
    description: Detailed message about the result.
    returned: always
    type: str
'''


class Action(Enum):
    CREATE = 1
    MODIFY = 2
    DROP = 3
    NONE = 0


def execute_query(client, module, query):
    try:
        result = client.execute(query, with_column_types=True)
        return result
    except NetworkError as e:
        module.fail_json(msg=f"Network error occurred: {e}")
    except ServerException as e:
        module.fail_json(msg=f"Server returned an error: {e}")
    except Error as e:
        module.fail_json(msg=f"An error occurred: {e}")
    except Exception as e:
        module.fail_json(msg=f"Unexpected error: {e}")
    finally:
        client.disconnect()


def format_query_result(result):
    data, columns = result
    column_names = [col[0] for col in columns]
    formatted_result = [dict(zip(column_names, row)) for row in data]
    if formatted_result:
        return formatted_result
    return None


def get_role_info(client, module):
    role = module.params['role']
    role_sql = '''
    SELECT
    r.name AS role,
    spe.inherit_profile AS settings_profile
    FROM system.roles AS r
    LEFT JOIN system.settings_profile_elements AS spe
    ON r.name=spe.role_name
    WHERE r.name = '{}'
    GROUP BY r.name, spe.inherit_profile;'''

    result = execute_query(client, module, role_sql.format(role))
    formatted_result = format_query_result(result)
    if formatted_result:
        return formatted_result[0]
    return None


def get_role_privileges(client, module):
    role = module.params['role']
    role_privileges_sql = '''
    SELECT
    if(g.database IS NOT NULL, g.database, '*' ) AS db,
    if(g.table IS NOT NULL, g.table, '*' ) AS table,
    groupArray(g.access_type) AS grants
    FROM system.grants AS g
    WHERE g.role_name = '{}'
    GROUP BY g.role_name, g.database, g.table;'''

    result = execute_query(client, module, role_privileges_sql.format(role))
    formatted_result = format_query_result(result)
    if formatted_result:
        return formatted_result
    return []


def validate_role_exists(client, module):
    role_info = get_role_info(client, module)
    if role_info:
        return True
    return False


def validate_role(client, module):
    settings_profile = module.params['settings_profile']
    privileges = module.params['privileges']
    role_info = get_role_info(client, module)
    role_privileges = get_role_privileges(client, module)
    if len(privileges):
        for item in privileges:
            if 'grants' in item:
                item['grants'].sort()
    if len(role_privileges):
        for item in role_privileges:
            if 'grants' in item:
                item['grants'].sort()
    if role_info:
        if settings_profile != role_info['settings_profile']:
            return False
        if privileges != role_privileges:
            return False
        return True
    return False


def validate_privileges_diff(client, module):
    privileges = module.params['privileges']
    role_privileges = get_role_privileges(client, module)
    for item in privileges:
        item['grants'].sort()
    for item in role_privileges:
        item['grants'].sort()
    if privileges != role_privileges:
        privileges_diff = []
        for item in role_privileges:
            if item not in privileges:
                privileges_diff.append(item)
                privileges_diff.append(privileges[0])
        return privileges_diff
    return False


def construct_sql(module, action, privileges_diff):
    role = module.params['role']
    privileges = module.params['privileges']
    cluster_suffix = f" ON CLUSTER {module.params['cluster_name']}" if module.params.get('cluster_name') else ""
    settings_profile_part = f"SETTINGS PROFILE '{module.params['settings_profile']}'" \
        if module.params.get('settings_profile') else ""
    sql = []

    if action in [Action.CREATE, Action.MODIFY]:
        if action == Action.CREATE:
            sql.append(f"CREATE ROLE {role} {cluster_suffix} {settings_profile_part}")
        elif action == Action.MODIFY:
            sql.append(f"ALTER ROLE {role} {cluster_suffix} {settings_profile_part}")
        for d in privileges_diff:
            sql.append(f"REVOKE {cluster_suffix} {', '.join(d['grants'])} ON {d['db']}.{d['table']} FROM {role}")
        for p in privileges:
            sql.append(f"GRANT {cluster_suffix} {', '.join(p['grants'])} ON {p['db']}.{p['table']} TO {role}")
    elif action == Action.DROP:
        sql.append(f"DROP ROLE {role} {cluster_suffix}")
    else:
        module.fail_json(msg="Invalid action specified")
    return sql


def run_module():
    module_args = {
        'ch_host': {'type': 'str', 'required': True},
        'ch_port': {'type': 'int', 'default': 9000},
        'ch_user': {'type': 'str', 'default': 'default'},
        'ch_password': {'type': 'str', 'no_log': True, 'default': ''},
        'state': {'type': 'str', 'required': False, 'default': 'present', 'choices': ['present', 'absent']},
        'role': {'type': 'str', 'required': True},
        'privileges': {'type': 'list', 'elements': 'dict', 'default': []},
        'settings_profile': {'type': 'str'},
        'cluster_name': {'type': 'str'},
        'force': {'type': 'bool', 'default': False},
    }

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    ch_host = module.params['ch_host']
    ch_port = module.params['ch_port']
    ch_user = module.params['ch_user']
    ch_password = module.params['ch_password']
    state = module.params['state']
    force = module.params['force']
    action = Action.NONE

    client = clickhouse_driver.Client(host=ch_host, port=ch_port, user=ch_user, password=ch_password)

    role_exists = validate_role_exists(client, module)
    privileges_diff = []

    if state == 'present' and role_exists:
        role_valid = validate_role(client, module)
        if role_valid and not force:
            module.exit_json(changed=False, message="Role already exists with the same privileges and settings")
        else:
            privileges_diff = validate_privileges_diff(client, module)
            action = Action.MODIFY
    elif state == 'present' and not role_exists:
        action = Action.CREATE
    elif state == 'absent' and role_exists:
        action = Action.DROP
    else:
        module.exit_json(changed=False, message="Role does not exist")
    sql = construct_sql(module, action, privileges_diff)
    for s in sql:
        execute_query(client, module, s)
    module.exit_json(changed=True, message=f"Role {module.params['role']} has been {action.name.lower()}ed")


def main():
    run_module()


if __name__ == '__main__':
    main()
