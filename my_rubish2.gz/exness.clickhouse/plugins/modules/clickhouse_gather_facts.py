from ansible.module_utils.basic import AnsibleModule
import clickhouse_driver
from clickhouse_driver.errors import NetworkError, ServerException, Error

DOCUMENTATION = r'''
module: clickhouse_gather_facts
short_description: Gathers information from ClickHouse server.
version_added: "1.0.0"
description: This module collects  information from a ClickHouse server.
options:
    ch_host:
        description: Hostname or IP of the ClickHouse server.
        required: true
        type: str
    ch_port:
        description: Port number of the ClickHouse server.
        required: false
        default: 9000
        type: int
    ch_user:
        description: Username for authentication with the ClickHouse server.
        required: false
        default: 'default'
        type: str
    ch_password:
        description: Password for authentication with the ClickHouse server.
        required: false
        default: ''
        type: str
author:
    - Dmitry Nikitin DBA <<dmitry.nikitin@exness.com>>
'''

EXAMPLES = r'''
- name: Gather cluster information from ClickHouse
  clickhouse_gather_facts:
    ch_host: 'clickhouse-server.example.com'
    ch_user: 'admin'
    ch_password: 'password'
  register: result

- debug:
    msg: "{{ result.info }}"
'''

RETURN = r'''
info:
    description: The gathered information from the ClickHouse server.
    returned: always
    type: complex
    contains:
        cluster_info:
            description: Details about ClickHouse clusters.
            type: dict
        database_info:
            description: Information on databases and tables.
            type: dict
        user_info:
            description: Data on users and roles.
            type: dict
        config_info:
            description: Current configuration settings of the server.
            type: dict
'''


def execute_query(client, module, query):
    try:
        result = client.execute(query, with_column_types=True)
        return result
    except NetworkError as e:
        module.fail_json(msg=f"Network error occurred: {e}")
    except ServerException as e:
        module.fail_json(msg=f"Server returned an error: {e}")
    except Error as e:
        module.fail_json(msg=f"An error occurred: {e}")
    except Exception as e:
        module.fail_json(msg=f"Unexpected error: {e}")
    finally:
        client.disconnect()


def format_query_result(result):
    data, columns = result
    column_names = [col[0] for col in columns]
    formatted_result = [dict(zip(column_names, row)) for row in data]
    if formatted_result:
        return formatted_result
    return None


def run_module():
    module_args = dict(
        ch_host=dict(type='str', required=True),
        ch_port=dict(type='int', required=False, default=9000),
        ch_user=dict(type='str', required=False, default='default'),
        ch_password=dict(type='str', required=False, no_log=True, default=''))

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True)

    result = dict(
        changed=False,
        info=None)

    if module.check_mode:
        module.exit_json(**result)

    # Connect to ClickHouse server
    client = clickhouse_driver.Client(
        host=module.params['ch_host'],
        port=module.params['ch_port'],
        user=module.params['ch_user'],
        password=module.params['ch_password'])

    try:
        # Execute a query to get local cluster names
        local_clusters_query = """
            select cluster AS cluster, 
            groupArray(host_name) AS hosts
            from system.clusters
            WHERE cluster IN (
             select cluster from system.clusters where is_local = 1
            )
            AND cluster NOT LIKE 'test_%'
            AND host_name NOT LIKE 'localhost'
            group by cluster;"""

        local_clusters_formatted_result = format_query_result(execute_query(client, module, local_clusters_query))

        # Execute a query to get remote cluster names
        remote_clusters_query = """
            select cluster AS cluster, 
            groupArray(host_name) AS hosts
            from system.clusters
            where is_local = 0
            AND cluster NOT IN (
             select cluster from system.clusters where is_local = 1
            )
            AND cluster NOT LIKE 'test_%'
            group by cluster;"""
        remote_clusters_formatted_result = format_query_result(execute_query(client, module, remote_clusters_query))

        # Execute a query to get node settings_profiles
        node_settings_profiles_formatted_result = format_query_result(
            execute_query(client, module, "SELECT name FROM system.settings_profiles;"))
        node_settings_profiles_names = [item['name'] for item in node_settings_profiles_formatted_result]

        # Execute a query to get user and roles
        users_and_roles_query = """select u.name AS user,
            u.auth_type AS auth_type,
            arrayDistinct(groupArray(if(length(rg.granted_role_name) > 0, rg.granted_role_name, NULL))) AS roles,
            spe.inherit_profile AS settings_profile
            from system.users AS u
            left join system.settings_profile_elements AS spe
            on u.name = spe.user_name
            left join system.role_grants AS rg
            on u.name = rg.user_name
            group by u.name, u.auth_type, spe.inherit_profile
            order by u.name;"""
        users_and_roles_formatted_result = format_query_result(execute_query(client, module, users_and_roles_query))

        # Execute a query to get databases
        databases_query = """SELECT d.name AS database,
            arrayDistinct(groupArray(if(length(g.role_name) > 0, g.role_name, NULL))) AS roles,
            arrayDistinct(groupArray(if(length(t.engine) > 0, t.engine, NULL))) AS engines,
            arrayDistinct(groupArray(if(length(c.cluster) > 0, c.cluster, NULL))) AS clusters
            FROM system.databases d
            LEFT JOIN system.grants g
            ON g.database = d.name
            LEFT JOIN system.tables t
            ON t.database = d.name
            LEFT JOIN system.replicas r
            ON r.table = t.name AND r.database = t.database
            LEFT JOIN system.clusters c
            ON c.host_name = r.replica_name OR c.host_address = r.replica_name
            WHERE d.name NOT IN ('INFORMATION_SCHEMA', 'default', 'information_schema', 'system')
            GROUP BY d.name;"""
        databases_formatted_result = format_query_result(execute_query(client, module, databases_query))

        # Execute a query to get clickhouse-server version
        version_query = "SELECT version() AS version;"
        version_formatted_result = format_query_result(execute_query(client, module, version_query))
        version_value = version_formatted_result[0]['version']

        # Execute a query to get clickhouse-server config
        config_query = "SELECT name, value FROM system.settings;"
        config = execute_query(client, module, config_query)
        config_data, config_columns = config
        config_formatted_result = {row[0]: row[1] for row in config_data}

        # Process and format the data as needed
        cluster_info = {
            'local_clusters': local_clusters_formatted_result,
            'remote_clusters': remote_clusters_formatted_result,
        }
        user_info = {
            'node_settings_profiles': node_settings_profiles_names,
            'users': users_and_roles_formatted_result
        }

        database_info = {
            'databases': databases_formatted_result
        }

        config_info = {
            'version': version_value,
            'settings': config_formatted_result
        }

        result = {
            'cluster_info': cluster_info,
            'config_info': config_info,
            'user_info': user_info,
            'database_info': database_info
        }
    except Exception as e:
        module.fail_json(msg='Failed to gather information', error=str(e), **result)

    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
