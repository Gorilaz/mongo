from ansible.module_utils.basic import AnsibleModule
import clickhouse_driver
from clickhouse_driver.errors import NetworkError, ServerException, Error
from enum import Enum

DOCUMENTATION = r'''
module: clickhouse_db_management
short_description: Manages databases in ClickHouse.
version_added: "1.0.0"
description: >
    This module allows for the creation, modification, and deletion of ClickHouse databases.
options:
    ch_host:
        description: Hostname or IP of the ClickHouse server.
        required: true
        type: str
    ch_port:
        description: Port number of the ClickHouse server.
        required: false
        default: 9000
        type: int
    ch_user:
        description: Username for authentication with the ClickHouse server.
        required: false
        default: 'default'
        type: str
    ch_password:
        description: Password for authentication with the ClickHouse server.
        required: false
        type: str
    cluster_name:
        description: Name of the cluster to manage.
        required: false
        type: str
    state:
        description: Desired state of the database ('absent' or 'present').
        required: false
        default: 'present'
        type: str
        choices: ['absent', 'present']
    db:
        description: Name of the database to manage.
        required: true
        type: str
    engine:
        description: By default, ClickHouse uses its own Atomic database engine. 
        here are also Lazy, MySQL, PostgresSQL, MaterializedMySQL, MaterializedPostgreSQL, Replicated, SQLite.
        default: 'Atomic'
        required: false
        type: str
    comment:
        description: Comment for the database.
        required: false
        type: str
    force:
        description: Whether to force the operation, applicable for 'present' state (optional).
        required: false
        default: False
        type: bool
author:
    - Dmitry Nikitin DBA <<dmitry.nikitin@exness.com>>
'''

EXAMPLES = r'''
- name: Ensure a database in ClickHouse is present
  clickhouse_db_management:
    ch_host: 'clickhouse-server.example.com'
    ch_user: 'admin'
    ch_password: 'password'
    cluster_name: 'test_cluster'
    state: 'present'
    db: 'test_db'
    comment: 'Test database'
'''

RETURN = r'''
message:
    description: Detailed message about the result.
    returned: always
    type: str
'''


class Action(Enum):
    CREATE = 1
    DROP = 2
    NONE = 0


def execute_query(client, module, query):
    try:
        result = client.execute(query, with_column_types=True)
        return result
    except NetworkError as e:
        module.fail_json(msg=f"Network error occurred: {e}")
    except ServerException as e:
        module.fail_json(msg=f"Server returned an error: {e}")
    except Error as e:
        module.fail_json(msg=f"An error occurred: {e}")
    except Exception as e:
        module.fail_json(msg=f"Unexpected error: {e}")
    finally:
        client.disconnect()


def format_query_result(result):
    data, columns = result
    column_names = [col[0] for col in columns]
    formatted_result = [dict(zip(column_names, row)) for row in data]
    if formatted_result:
        return formatted_result
    return None


def get_db_info(client, module):
    db = module.params['db']
    db_sql = '''
    SELECT name as db,
    engine,
    comment
    FROM system.databases
    WHERE name = '{}';
    '''
    result = execute_query(client, module, db_sql.format(db))
    formatted_result = format_query_result(result)
    if formatted_result:
        return formatted_result[0]
    return None


def validate_db_exists(client, module):
    db_info = get_db_info(client, module)
    if db_info:
        return True
    return False


def construct_sql(module, action):
    db = module.params['db']
    cluster_suffix = f" ON CLUSTER {module.params['cluster_name']}" if module.params.get('cluster_name') else ""
    sql = []
    engine_part = f"ENGINE = {module.params['engine']}" if module.params.get('engine') else ""
    comment_part = f"COMMENT '{module.params['comment']}'" if module.params.get('comment') else ""
    if action == Action.CREATE:
        sql.append(f"CREATE DATABASE IF NOT EXISTS {db} {cluster_suffix} {engine_part} {comment_part}")
    elif action == Action.DROP:
        sql.append(f"DROP DATABASE IF EXISTS {db} {cluster_suffix}")
    else:
        module.fail_json(msg="Invalid action specified")
    return sql


def run_module():
    module_args = {
        'ch_host': {'type': 'str', 'required': True},
        'ch_port': {'type': 'int', 'default': 9000},
        'ch_user': {'type': 'str', 'default': 'default'},
        'ch_password': {'type': 'str', 'no_log': True, 'default': ''},
        'state': {'type': 'str', 'required': False, 'default': 'present', 'choices': ['present', 'absent']},
        'db': {'type': 'str', 'required': True},
        'engine': {'type': 'str', 'default': 'Atomic'},
        'comment': {'type': 'str'},
        'cluster_name': {'type': 'str'},
        'force': {'type': 'bool', 'default': False},
    }

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    ch_host = module.params['ch_host']
    ch_port = module.params['ch_port']
    ch_user = module.params['ch_user']
    ch_password = module.params['ch_password']
    state = module.params['state']
    force = module.params['force']
    action = Action.NONE

    client = clickhouse_driver.Client(host=ch_host, port=ch_port, user=ch_user, password=ch_password)

    db_exists = validate_db_exists(client, module)

    if state == 'present' and db_exists:
        if not force:
            module.exit_json(changed=False, message="DB already exists.")
        else:
            action = Action.CREATE
    elif state == 'present' and not db_exists:
        action = Action.CREATE
    elif state == 'absent' and db_exists:
        action = Action.DROP
    else:
        module.exit_json(changed=False, message="DB does not exist")
    sql = construct_sql(module, action)
    for s in sql:
        execute_query(client, module, s)
    module.exit_json(changed=True, message=f"DB {module.params['db']} has been {action.name.lower()}ed")


def main():
    run_module()


if __name__ == '__main__':
    main()
