#!/usr/bin/env python3

# This script check if last successfull backup was finished 

import sys
import os
import logging
import subprocess
import json
from dateutil.parser import parse
import datetime
import pytz


# We can pass parameter into scritpt like this
# check_last_backup.py 1d  / check_last_backup.py  7d
# if we pass it then we use it. If not TIME_FRAME = 1
# TIME_FRAME is a time interval.

if len(sys.argv)>1:
    TIME_FRAME = sys.argv[1]
    TIME_FRAME = int(TIME_FRAME[:-1])
else:
    TIME_FRAME = 1

LOGGER = logging.getLogger('check_last_backup')
LOGGER.setLevel(logging.INFO)
HANDLER = logging.FileHandler('/var/log/zabbix' + '/check_last_backup.log')
LOG_FORMAT = logging.Formatter('%(name)s [%(asctime)s] [%(levelname)s] %(message)s')
HANDLER.setFormatter(LOG_FORMAT)
LOGGER.addHandler(HANDLER)


# This function get current time and minus TIME_FRAME.
def get_time_point(TIME_FRAME):
    utc=pytz.UTC
    time_point = datetime.datetime.now() - datetime.timedelta(days=TIME_FRAME)
    time_point = utc.localize(time_point)
    return time_point


# This function set environment. Without PBM_MONGODB_URI env we cannot execute pbm list
def set_env():
    cmd_line = ['/bin/cat', '/etc/sysconfig/pbm-agent']
    proc_exec = subprocess.Popen(cmd_line, stdout=subprocess.PIPE)
    for line in iter(proc_exec.stdout.readline, b''):
        str_line = line.decode()
        arr_str = str_line.split()
        if arr_str:
            str_list = str_line.split('"')
            os.environ['PBM_MONGODB_URI'] = str_list[1]


# This function parse output pbm list to get time of last successfull backup
def get_backup_list():
    cmd_line = ['/usr/bin/pbm', 'list','-o','json']
    proc_exec = subprocess.Popen(cmd_line, stdout=subprocess.PIPE)
    for line in iter(proc_exec.stdout.readline, b''):
        str_line = line.decode()
        json_result = json.loads(str_line)

    snapshots = json_result["snapshots"]
    amount_backups = len(snapshots)
    last_backup_data = snapshots[amount_backups-1]
    date_backup = last_backup_data["name"]
    last_date_backup = parse(date_backup)

    # current time - TIME_FRAME
    time_point = get_time_point(TIME_FRAME)

    # If time past since last successfull backup greater than time_point then alarm
    if last_date_backup > time_point:
        print(0)
    else:
        print(1)
        LOGGER.info("Backup was not done in specific time window(%s) ",TIME_FRAME)


if __name__ == '__main__':
    set_env()
    get_backup_list()
