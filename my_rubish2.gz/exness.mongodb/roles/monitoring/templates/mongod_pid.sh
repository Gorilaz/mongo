#!/bin/sh
pid=$(pgrep -f '/usr/bin/mongod')
if [ -z "$pid" ]; then
  echo 0
else
  echo "$pid"
fi
