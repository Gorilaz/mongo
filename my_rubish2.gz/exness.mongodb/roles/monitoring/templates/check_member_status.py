#!/usr/bin/env python3

import logging
from pymongo import MongoClient
import sys
import re

LOGGER = logging.getLogger('check_replication')
LOGGER.setLevel(logging.INFO)

HANDLER = logging.FileHandler('/var/log/zabbix' + '/check_replication.log')
LOG_FORMAT = logging.Formatter('%(name)s [%(asctime)s] [%(levelname)s] %(message)s')
HANDLER.setFormatter(LOG_FORMAT)
LOGGER.addHandler(HANDLER)
LIST_STATUS_NODES = ['PRIMARY',
                     'SECONDARY',
                     'ARBITER',
                     ]


def failed():
    print(1)


def success():
    print(0)


# function check node's state in cluster if state is not in (PRIMARY','SECONDARY','ARBITER') - alarm
def check_replicaset():
    # Read the MongoDB URI from the /etc/sysconfig/pbm-agent file
    with open('/etc/sysconfig/pbm-agent', 'r') as f:
        lines = f.readlines()

    # Search for the PBM_MONGODB_URI line and extract the URI
    for line in lines:
        if line.startswith('PBM_MONGODB_URI='):
            # Extracting the URI without the quotes
            uri = re.search('"([^"]*)"', line).group(1)
            break
    else:
        LOGGER.error("MongoDB URI not found in /etc/sysconfig/pbm-agent")
        sys.exit(1)

    # Use the extracted URI for the connection string
    connect_string = uri
    client = MongoClient(connect_string)
    mongodb = client.admin
    db_stats = mongodb.command({'replSetGetStatus': 1})
    members = db_stats['members']
    for member in members:
        member_state = member['stateStr']
        if member_state in LIST_STATUS_NODES:
            continue
        else:
            LOGGER.info("We have problem with node - %s. It has state - %s ", member['name'], member_state)
            failed()
            sys.exit()

    success()


if __name__ == '__main__':
    check_replicaset()
