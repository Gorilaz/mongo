# Greenmask Configs



list

docker run -it   -v /home/sergei.gavrilov/greenmask:/app  -e PGPASSWORD=greenmask_user_pass  greenmask/greenmask:latest list-dumps --config=/app/config_survey_management.yml


restore

docker run -it   -v /home/sergei.gavrilov/greenmask:/app  -e PGPASSWORD=greenmask_user_pass  greenmask/greenmask:latest restore 1737101346875 --config=/app/config_survey_management.yml


dump

docker run -it   -v /home/sergei.gavrilov/greenmask:/app  -e PGPASSWORD=greenmask_user_pass  greenmask/greenmask:latest dump --config=/app/config_document_management.yml



